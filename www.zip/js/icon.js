(function() {
  var s = Snap("#svg");
  // Lets create big circle in the middle:
  var bigCircle = s.circle(150, 150, 100);
})();